#ifndef Money_H
#define Money_H

class money {
private:
	int ammount;
public:
	money();
	void increaseMoney(int);
	void decreaseMoney(int);
	void setMoney(int);

	int getMoney();
	~money();
};
int money::getMoney() {
	return ammount;
}
money::money() {
	ammount = 0;
}
void money::increaseMoney(int m) {
	ammount += m;
}
void money::decreaseMoney(int m) {
	ammount -= m;
}
void money::setMoney(int m) {
	ammount = m;
}
money::~money() {

}


#endif // !Money_H
