#ifndef player_H
#define player_H
#include"money.h"
#include<fstream>
#include<iostream>
#include<string.h>

using namespace std;

class player:public money {
private:
	int PlayerNumber;
	int owner[38];
	int numberOfProperties;
	bool inJail;
	bool Retire;
	bool Bankrupt;
	int move[2][40];
	int currentPosition;
	
public:
	player();
	void setPosition(int position);
	void setPositionUnconditionally(int);
	void setPlayerNumber(int);
	void setOwner(int);
	void removeOwner(int);

	int getPosition();
	int getOwner(int);
	int getX();
	int houseOwner = 0;
	int hostelOwner = 0;
	int getY();
	string getPicture();
};

void player::setPositionUnconditionally(int p) {
	currentPosition = p;
}

void player::setOwner(int o) {
	owner[numberOfProperties] = o;
	numberOfProperties++;
}
void player::setPlayerNumber(int p) {
	PlayerNumber = p;
}
player::player() {
	numberOfProperties = 0;
	ifstream fin;
	fin.open("Data\\Position.txt");
	for (int i = 0; i < 40; i++) {
		for (int j = 0; j < 2; j++) {
			fin >> move[j][i];
		}
	}
	currentPosition = 0;
	PlayerNumber = 0;
	inJail = false;
	Retire = false;
	Bankrupt = false;
}

int player:: getOwner(int o) {
	if (owner != NULL) {
		for (int i = 0; owner[i] != -1; i++) {
			if (o == owner[i]) {
				return i;
			}
		}
	}
	return -2;
}
void player::removeOwner(int p) {

	int size = 0;
	for (int i = 0; owner[i] != -1; i++) {
		size++;
	}

	for (int i = 0; i< size; i++) {
		if (p == owner[i]) {
			for (int j = i; j < sizer; j++) {
				owner[j] = owner[j++];
			}
		}
	}
	
}

void player::setPosition(int position) {
	currentPosition += position;
	if (currentPosition >= 40) {
		increaseMoney(200);
		int temp = 40;
		int temp2 = currentPosition - temp;
		currentPosition = temp2;
	}
}

int player::getX() {
	return move[0][currentPosition];
}
int player::getY() {
	return move[1][currentPosition];
}
string player:: getPicture() {
	if (PlayerNumber == 0) {
		return"Images\\Pieces\\Pieces0.png";
	}
	else if(PlayerNumber == 1) {
		return"Images\\Pieces\\Pieces1.png";
	}
	else if (PlayerNumber == 2) {
		return"Images\\Pieces\\Pieces2.png";
	}
	else if (PlayerNumber == 3) {
		return"Images\\Pieces\\Pieces3.png";
	}
	else if (PlayerNumber == 4) {
		return"Images\\Pieces\\Pieces4.png";
	}
	else if (PlayerNumber == 5) {
		return"Images\\Pieces\\Pieces5.png";
	}
	else if (PlayerNumber == 6) {
		return"Images\\Pieces\\Pieces6.png";
	}
}

int player:: getPosition() {
	return currentPosition;
}

#endif