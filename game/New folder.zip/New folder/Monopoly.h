#ifndef Monopoly_H
#define Monopoly_H
#include<SFML/Graphics.hpp>
#include"Dice.h"
#include"CommunityChest.h"
#include"chance.h"
#include"player.h"
#include"property.h"
#include<iostream>

using namespace std;


class Monopoly {
private:
	property land[40];
	int x;
	int y;
	int turn;
	int totalPlayer;
	int money;
	sf::Event event;
	void setpropertyInfo();

public:
	Monopoly();
	void drawBoard();
	void UpdateTurn();
	void assignProperty(player *p,int, int);
	void moneyAction(player *p, int, int, int);
	void PropertyRentAction(player *p, int);
	void propertyBuyAction(player *p, int);
	~Monopoly();
};



void Monopoly::setpropertyInfo() {
	

	land[0].setUpgradeStatus(0, 0);


	land[1].setSalePrice(250);
	land[1].setRent(250);
	land[1].setGroup("IQBAL");
	land[1].setUpgradeStatus(1,1);
	
	land[2].setUpgradeStatus(0, 0);

	land[3].setSalePrice(300);
	land[3].setRent(300);
	land[3].setGroup("IQBAL");
	land[3].setUpgradeStatus(1,1);
	
	land[4].setSalePrice(400);
	land[4].setRent(400);
	land[4].setGroup("IQBAL");
	land[4].setUpgradeStatus(1,1);

	land[5].setSalePrice(2000);
	land[5].setRent(200);
	land[5].setGroup("STATION");
	land[5].setUpgradeStatus(0, 1);


	land[6].setSalePrice(200);
	land[6].setRent(200);
	land[6].setGroup("JOHAR");
	land[6].setUpgradeStatus(1,1);

	land[7].setUpgradeStatus(0, 0);

	land[8].setSalePrice(250);
	land[8].setRent(250);
	land[8].setGroup("JOHAR");
	land[8].setUpgradeStatus(1,1);

	land[9].setSalePrice(2000);
	land[9].setRent(200);
	land[9].setGroup("STATION");
	land[9].setUpgradeStatus(0, 1);

	land[10].setUpgradeStatus(0, 0);

	land[11].setSalePrice(300);
	land[11].setRent(300);
	land[11].setGroup("FAISAL");
	land[11].setUpgradeStatus(1,1);

	land[12].setSalePrice(5000);
	land[12].setRent(450);
	land[12].setGroup("UTILITY");
	land[12].setUpgradeStatus(0, 1);

	land[13].setSalePrice(400);
	land[13].setRent(400);
	land[13].setGroup("FAISAL");
	land[13].setUpgradeStatus(1,1);

	land[14].setSalePrice(400);
	land[14].setRent(400);
	land[14].setGroup("FAISAL");
	land[14].setUpgradeStatus(1,1);

	land[15].setSalePrice(2000);
	land[15].setRent(200);
	land[15].setGroup("STATION");
	land[15].setUpgradeStatus(0, 1);
	
	land[16].setSalePrice(800);
	land[16].setRent(800);
	land[16].setGroup("MODEL");
	land[16].setUpgradeStatus(1,1);

	land[17].setUpgradeStatus(0, 0);

	land[18].setSalePrice(850);
	land[18].setRent(850);
	land[18].setGroup("MODEL");
	land[18].setUpgradeStatus(1,1);

	land[19].setSalePrice(2000);
	land[19].setRent(2000);
	land[19].setGroup("MODEL");
	land[19].setUpgradeStatus(1,1);

	land[20].setUpgradeStatus(0, 0);

	land[21].setSalePrice(1000);
	land[21].setRent(1000);
	land[21].setGroup("GULBERG");
	land[21].setUpgradeStatus(1,1);

	land[22].setUpgradeStatus(0, 0);

	land[23].setSalePrice(1200);
	land[23].setRent(1200);
	land[23].setGroup("GULBERG");
	land[23].setUpgradeStatus(1,1);

	land[24].setSalePrice(2500);
	land[24].setRent(2500);
	land[24].setGroup("GULBERG");
	land[24].setUpgradeStatus(1,1);

	land[25].setSalePrice(2500);
	land[25].setRent(350);
	land[25].setGroup("STATION");
	land[25].setUpgradeStatus(0, 1);

	land[26].setSalePrice(8000);
	land[26].setRent(500);
	land[26].setGroup("UTILITY");
	land[26].setUpgradeStatus(0, 1);


	land[27].setSalePrice(2000);
	land[27].setRent(2000);
	land[27].setGroup("DHA");
	land[27].setUpgradeStatus(1,1);

	land[28].setUpgradeStatus(0, 0);

	land[29].setSalePrice(2000);
	land[29].setRent(2000);
	land[29].setGroup("DHA");
	land[29].setUpgradeStatus(1,1);

	land[30].setUpgradeStatus(0, 0);

	land[31].setSalePrice(2500);
	land[31].setRent(35);
	land[31].setGroup("UTILITY");
	land[31].setUpgradeStatus(0, 1);

	land[32].setSalePrice(2500);
	land[32].setRent(2500);
	land[32].setGroup("DHA");
	land[32].setUpgradeStatus(1,1);

	land[33].setUpgradeStatus(0, 0);

	land[34].setSalePrice(2500);
	land[34].setRent(2500);
	land[34].setGroup("BAHRIA");
	land[34].setUpgradeStatus(1,1);

	land[35].setSalePrice(2500);
	land[35].setRent(350);
	land[35].setGroup("STATION");
	land[35].setUpgradeStatus(0, 1);

	land[36].setUpgradeStatus(0, 0);

	land[37].setSalePrice(3000);
	land[37].setRent(3000);
	land[37].setGroup("BAHRIA");
	land[37].setUpgradeStatus(1,1);

	land[38].setUpgradeStatus(0, 0);

	land[39].setSalePrice(3000);
	land[39].setRent(3000);
	land[39].setGroup("BAHRIA");
	land[39].setUpgradeStatus(1,1);

}
void Monopoly::assignProperty(player *p,int position, int own) {
	int temp[12] = { 0,2,7,10,17,20,22,28,30,33,36,38 };
	bool isFound = false;;
	for (int i = 0; i < 12; i++) {
		if (position == temp[i]) {
			isFound = true;
		}
	}
	if (!isFound && (land[position].getOwner() == -2)) {
		land[position].setOwner(own);
		p[own].setOwner(position);
	}
}
void Monopoly::moneyAction(player *p, int firstPlayer, int secondPlayer, int amount) {
	p[firstPlayer].decreaseMoney(amount);
	cout << "\t amount : " << amount<<endl;
	if (secondPlayer != -1) {
		p[secondPlayer].increaseMoney(amount);
	}
}



Monopoly::Monopoly() {
	setpropertyInfo();
	x = 0;
	y = 0;
	for (int i = 0; i < 40; i++) {
		land[i].setPropertyId(i);
	}
	totalPlayer = 0;
	money = 0;
	turn = 0;
}
void Monopoly::UpdateTurn() {
	
	if (turn + 1 == totalPlayer) {
		turn = 0;
	}
	else {
		turn++;
	}
}
void  Monopoly::PropertyRentAction(player *p, int turn) {
	int position = p[turn].getPosition();
	int landOwner = land[position].getOwner();
	int owner = p[turn].getOwner(land[position].getOwner());
	
	if (landOwner != owner) {
		cout << "\tpay : " << p[turn].getMoney() << endl;
		cout << "\t receive : " << p[land[position].getOwner()].getMoney() << endl;
		moneyAction(p, turn, land[position].getOwner(), land[position].getRent());
		cout << "\tpay : " << p[turn].getMoney() << endl;
		cout << "\t receive : " << p[land[position].getOwner()].getMoney() << endl;
	}
}
void Monopoly::propertyBuyAction(player *p, int) {
	int position = p[turn].getPosition();
	int landOwner = land[position].getOwner();
	int owner = p[turn].getOwner(land[position].getOwner());
	int landPrice = land[position].getSalePrice();
	if (owner != -1) {
		p[owner].increaseMoney(landPrice);
		p[owner].removeOwner(position);
		p[turn].decreaseMoney(landPrice);
		p[turn].setOwner(position);
	}
	else {
		p[turn].decreaseMoney(landPrice);
		p[turn].setOwner(position);
	}
}

void Monopoly::drawBoard() {
	
	
	bool isSelect = false;
	bool isCancel = false;

	sf::Texture selectPlayer;
	sf::Sprite selectPlayerLoad;
	
	selectPlayer.loadFromFile("Images\\select player\\player0.png");
	selectPlayerLoad.setTexture(selectPlayer);

	sf::RenderWindow selectPlayerWindow(sf::VideoMode(800, 650), "Monopoly", sf::Style::Titlebar | sf::Style::Close);
	selectPlayerWindow.setKeyRepeatEnabled(false);
	while (selectPlayerWindow.isOpen()) {

		while (selectPlayerWindow.pollEvent(event)) {
			if (event.type == sf::Event::Closed) {
				selectPlayerWindow.close();
				isCancel = true;
			}
			else if (sf::Event::MouseButtonPressed) {
				if (event.mouseButton.button == sf::Mouse::Left) {
					if (event.mouseButton.y > 240 && event.mouseButton.y < 300) {
						if (event.mouseButton.x > 180 && event.mouseButton.x < 220) {
							selectPlayer.loadFromFile("Images\\select player\\player2.png");
							totalPlayer = 2;
							isSelect = true;
						}
						else if (event.mouseButton.x > 310 && event.mouseButton.x < 360) {
							selectPlayer.loadFromFile("Images\\select player\\player3.png");
							totalPlayer = 3;
							isSelect = true;
						}
						else if (event.mouseButton.x > 440 && event.mouseButton.x < 490) {
							selectPlayer.loadFromFile("Images\\select player\\player4.png");
							isSelect = true;
							totalPlayer = 4;
						}
						else if (event.mouseButton.x > 560 && event.mouseButton.x < 620) {
							selectPlayer.loadFromFile("Images\\select player\\player5.png");
							isSelect = true;
							totalPlayer = 5;
						}
					}
					else if (event.mouseButton.y > 420 && event.mouseButton.y < 510) {
						if (event.mouseButton.x > 340 && event.mouseButton.x < 480 && isSelect) {
							selectPlayerWindow.close();
						}
					}
				}
			}
		}
		selectPlayerWindow.draw(selectPlayerLoad);
		selectPlayerWindow.display();
	}
	if (!isCancel) {

		sf::Texture selectMoney;
		sf::Sprite selectMoneyLoad;

		selectMoney.loadFromFile("Images\\select money\\money0.png");
		selectMoneyLoad.setTexture(selectMoney);
		isSelect = false;

		sf::RenderWindow selectMoneyWindow(sf::VideoMode(800, 650), "Monopoly", sf::Style::Titlebar | sf::Style::Close);
		selectMoneyWindow.setKeyRepeatEnabled(false);
		while (selectMoneyWindow.isOpen()) {

			while (selectMoneyWindow.pollEvent(event)) {
				if (event.type == sf::Event::Closed) {
					selectMoneyWindow.close();
					isCancel = true;
				}
				else if (sf::Event::MouseButtonPressed) {
					if (event.mouseButton.button == sf::Mouse::Left) {
						if (event.mouseButton.y > 280 && event.mouseButton.y < 305) {
							if (event.mouseButton.x > 100 && event.mouseButton.x < 250) {
								selectMoney.loadFromFile("Images\\select money\\money2000.png");
								money = 2000;
								isSelect = true;
							}
							else if (event.mouseButton.x > 250 && event.mouseButton.x < 400) {
								selectMoney.loadFromFile("Images\\select money\\money3000.png");
								money = 3000;
								isSelect = true;
							}
							else if (event.mouseButton.x > 400 && event.mouseButton.x < 550) {
								selectMoney.loadFromFile("Images\\select money\\money4000.png");
								money = 4000;
								isSelect = true;
							}
							else if (event.mouseButton.x > 550 && event.mouseButton.x < 700) {
								selectMoney.loadFromFile("Images\\select money\\money5000.png");
								money = 5000;
								isSelect = true;
							}
						}
						else if (event.mouseButton.y > 430 && event.mouseButton.y < 480 && isSelect) {
							if (event.mouseButton.x > 300 && event.mouseButton.x < 510 && isSelect) {
								selectMoneyWindow.close();
							}
						}
					}
				}
			}
			selectMoneyWindow.draw(selectMoneyLoad);
			selectMoneyWindow.display();
		}

		if (!isCancel) {
			dice d;
			CommunityChest c;
			chance ch;
			player *p;
			p = new player[totalPlayer];
			for (int i = 0; i < totalPlayer; i++) {
				p[i].setPlayerNumber(i);
				p[i].setMoney(money);
			}



			sf::RenderWindow window(sf::VideoMode(800, 650), "Monopoly", sf::Style::Titlebar | sf::Style::Close);
			window.setKeyRepeatEnabled(false);


			sf::Texture board;
			sf::Texture Dice[2];
			sf::Texture community;
			sf::Texture chancePic;
			sf::Texture *symbol;
			symbol = new sf::Texture[totalPlayer];

			sf::Sprite boardLoad;
			sf::Sprite DiceLoad[2];
			sf::Sprite communityLoad;
			sf::Sprite chanceLoad;
			sf::Sprite *symbolLoad;
			symbolLoad = new sf::Sprite[totalPlayer];

			board.loadFromFile("Images\\main board\\Monopoly.jpg");
			Dice[0].loadFromFile("Images\\Dice\\dice1.png");
			Dice[1].loadFromFile("Images\\Dice\\dice5.png");
			chancePic.loadFromFile("Images\\Chance\\chanceTemplate 0.jpg");
			community.loadFromFile("Images\\Community Chest\\communityTemplate 0.jpg");

			for (int i = 0; i < totalPlayer; i++) {
				symbol[i].loadFromFile(p[i].getPicture());
			}


			DiceLoad[0].setTexture(Dice[0]);
			DiceLoad[1].setTexture(Dice[1]);
			boardLoad.setTexture(board);
			communityLoad.setTexture(community);
			chanceLoad.setTexture(chancePic);

			for (int i = 0; i < totalPlayer; i++) {
				symbolLoad[i].setTexture(symbol[i]);
			}



			chanceLoad.setPosition(325, 400);
			communityLoad.setPosition(130, 130);

			for (int i = 0; i < totalPlayer; i++) {
				symbolLoad[i].setPosition(p[i].getX(), p[i].getY());
			}
			DiceLoad[0].setPosition(390, 210);
			DiceLoad[1].setPosition(220, 350);
			int a = 0;


			while (window.isOpen()) {

				while (window.pollEvent(event)) {
					if (event.type == sf::Event::Closed || isCancel) {
						window.close();
					}
					else if (event.type == sf::Event::KeyPressed) {
						if (event.key.code == sf::Keyboard::R) {
							d.setDise();
							a++;
							cout << " " << a << " press R \n";
							Dice[0].loadFromFile(d.getDicePicture(d.getFirstNumber()));
							Dice[1].loadFromFile(d.getDicePicture(d.getSecondNumber()));
							DiceLoad[0].setTexture(Dice[0]);
							DiceLoad[1].setTexture(Dice[1]);
							DiceLoad[0].setPosition(390, 210);
							DiceLoad[1].setPosition(220, 350);

							p[turn].setPosition(d.getFirstNumber() + d.getSecondNumber());


							if (p[turn].getPosition() == 2 || p[turn].getPosition() == 17 || p[turn].getPosition() == 33) {
								community.loadFromFile(c.getCommunityPic());
								communityLoad.setTexture(community);
								communityLoad.setPosition(130, 130);
								c.comunityCardAction(p[turn], c.getCardNumber());
								cout << "\tcommunity" << turn << " : " << p[turn].getMoney() << endl;
							}
							if (p[turn].getPosition() == 7 || p[turn].getPosition() == 22 || p[turn].getPosition() == 36) {
								chancePic.loadFromFile(ch.getChancePic());
								chanceLoad.setTexture(chancePic);
								chanceLoad.setPosition(325, 400);
								ch.chanceCardAction(p, turn, totalPlayer);
								cout << "\tchyance" << turn << " : " << p[turn].getMoney() << endl;
							}
							symbolLoad[turn].setPosition(p[turn].getX(), p[turn].getY());
							
							PropertyRentAction(p, turn);
							
							assignProperty(p, p[turn].getPosition(), turn);
							if (d.getFirstNumber() != d.getSecondNumber()) {
								UpdateTurn();
							}
						}
					}
				}
				window.draw(boardLoad);
				window.draw(DiceLoad[0]);
				window.draw(DiceLoad[1]);
				window.draw(communityLoad);
				window.draw(chanceLoad);
				for (int i = 0; i < totalPlayer; i++) {
					window.draw(symbolLoad[i]);
				}

				window.display();
			}
		}
	}
}
Monopoly::~Monopoly() {

}
#endif // !Monopoly_H
