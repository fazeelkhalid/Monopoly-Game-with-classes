#include<iostream>
#include"Monopoly.h"

int main(){
	CommunityChest c;
	Monopoly M;
	M.drawBoard();


	return 0;
}