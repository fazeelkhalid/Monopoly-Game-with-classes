#ifndef property_H
#define property_H
#include<string.h>

class property {
private:
	int owner;
	char *group;
	int propertyId;
	int rent;
	bool upgradeStatus;
	bool buyStatus;
	int salePrice;
public:
	property() {
		owner = -1;
		propertyId = 0;
		rent = 0;
		group = NULL;
		upgradeStatus = false;
		buyStatus = false;
		salePrice = 0;
	}

	property(int p) {
		propertyId = p;
	}

	void setOwner(int);
	void setRent(int);
	void setPropertyId(int);
	void setSalePrice(int);
	void setUpgradeStatus(bool,bool);
	void setGroup(const char*);
	
	
	char* getGroup();
	int getOwner();
	int getPropertyId();
	int getRent();
	int getUpgradeStatus();
	int getButStatus();
	int getSalePrice();
};

void property::setUpgradeStatus(bool u, bool b) {
	upgradeStatus = u;
	buyStatus = b;
}


void property::setGroup(const char *g) {
	int size = strlen(g);
	group = new char[size + 1];
	strcpy_s(group, size+1, g);
	group[size] = '\0';
}
void property::setOwner(int o) {
	owner = o;
}

void property::setPropertyId(int p) {
	propertyId = p;
}

void property::setRent(int r) {
	rent = r;
}

void property::setSalePrice(int s) {
	salePrice = s;
}

char* property::getGroup() {
	return group;
}

int property::getOwner() {
	return owner;
}

int property::getPropertyId() {
	return propertyId;
}

int property::getRent() {
	return rent;
}

int property::getUpgradeStatus() {
	return upgradeStatus;
}

int property::getButStatus() {
	return buyStatus;
}

int property::getSalePrice() {
	return salePrice;
}

#endif // !property_H
